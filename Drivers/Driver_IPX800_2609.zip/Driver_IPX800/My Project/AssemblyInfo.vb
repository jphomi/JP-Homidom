﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Les informations générales relatives à un assembly dépendent de 
' l'ensemble d'attributs suivant. Changez les valeurs de ces attributs pour modifier les informations
' associées à un assembly.

' Passez en revue les valeurs des attributs de l'assembly

<Assembly: AssemblyTitle("Driver IPX800")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("HoMIDoM")> 
<Assembly: AssemblyProduct("Driver IPX800")> 
<Assembly: AssemblyCopyright("HoMIDoM")> 
<Assembly: AssemblyTrademark("HoMIDoM")> 

<Assembly: ComVisible(False)>

'Le GUID suivant est pour l'ID de la typelib si ce projet est exposé à COM
<Assembly: Guid("45f2ac59-cb13-4a21-8098-8db759bc3a7f")> 

' Les informations de version pour un assembly se composent des quatre valeurs suivantes :
'
'      Version principale
'      Version secondaire 
'      Numéro de build
'      Révision
'
' Vous pouvez spécifier toutes les valeurs ou indiquer les numéros de build et de révision par défaut 
' en utilisant '*', comme indiqué ci-dessous :
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.2.2.0")> 
<Assembly: AssemblyFileVersion("1.2.2.0")> 
